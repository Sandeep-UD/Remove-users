#!/usr/bin/env python3

import os
import csv
import time
import logging
import requests
from dotenv import load_dotenv
from datetime import datetime

# =========================================================
# Load ENV
# =========================================================

load_dotenv()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
ORG_NAME = os.getenv("ORG_NAME")

if not GITHUB_TOKEN:
    raise Exception("GITHUB_TOKEN missing in .env")

if not ORG_NAME:
    raise Exception("ORG_NAME missing in .env")

# =========================================================
# Config
# =========================================================

BASE_URL = "https://api.github.com"

HEADERS = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
}

USERS_CSV = "users.csv"
OUTPUT_CSV = "removed_users_report.csv"
ERROR_LOG = "error.log"

# =========================================================
# Logging
# =========================================================

logging.basicConfig(
    filename=ERROR_LOG,
    level=logging.ERROR,
    format="%(asctime)s %(levelname)s %(message)s"
)

# =========================================================
# Rate Limit Handler
# =========================================================

def handle_rate_limit(response):

    remaining = response.headers.get("X-RateLimit-Remaining")

    if remaining == "0":

        reset_time = int(response.headers.get("X-RateLimit-Reset", 0))

        sleep_time = max(reset_time - int(time.time()), 0) + 5

        print(f"\nRate limit hit. Sleeping {sleep_time} seconds...\n")

        time.sleep(sleep_time)

# =========================================================
# Read users.csv
# =========================================================

def read_users_csv():

    users = []

    if not os.path.exists(USERS_CSV):
        return users

    with open(USERS_CSV, "r", encoding="utf-8") as file:

        reader = csv.reader(file)

        for row in reader:

            if not row:
                continue

            username = row[0].strip()

            if username.lower() == "username":
                continue

            if username:
                users.append(username)

    return users

# =========================================================
# Get all org members
# =========================================================

def get_all_members():

    users = []

    page = 1
    per_page = 100

    while True:

        url = f"{BASE_URL}/orgs/{ORG_NAME}/members"

        params = {
            "per_page": per_page,
            "page": page
        }

        response = requests.get(
            url,
            headers=HEADERS,
            params=params
        )

        handle_rate_limit(response)

        if response.status_code != 200:

            print(f"\nFailed fetching users")
            print(response.status_code)
            print(response.text)

            logging.error(response.text)

            break

        data = response.json()

        if not data:
            break

        page_users = [x["login"] for x in data]

        users.extend(page_users)

        print(f"Fetched page {page} : {len(page_users)} users")

        page += 1

    return users

# =========================================================
# Remove User
# =========================================================

def remove_user(username):

    url = f"{BASE_URL}/orgs/{ORG_NAME}/members/{username}"

    response = requests.delete(
        url,
        headers=HEADERS
    )

    handle_rate_limit(response)

    # 204 = success
    if response.status_code == 204:

        print(f"Removed user : {username}")

        return "REMOVED"

    else:

        error_msg = (
            f"Failed removing {username} | "
            f"Status: {response.status_code} | "
            f"Response: {response.text}"
        )

        print(error_msg)

        logging.error(error_msg)

        return "FAILED"

# =========================================================
# Write CSV
# =========================================================

def write_csv(results):

    with open(
        OUTPUT_CSV,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        writer.writerow([
            "username",
            "status",
            "timestamp"
        ])

        writer.writerows(results)

# =========================================================
# Main
# =========================================================

def main():

    print("\n=================================================")
    print("GitHub Org User Removal")
    print("=================================================\n")

    users = read_users_csv()

    # If users.csv empty -> remove all users
    if not users:

        print("users.csv empty or missing")
        print("Fetching ALL organization users...\n")

        users = get_all_members()

    else:

        print(f"Users found in CSV : {len(users)}")

    print(f"\nTotal users to remove : {len(users)}\n")

    results = []

    for username in users:

        status = remove_user(username)

        results.append([
            username,
            status,
            datetime.utcnow().isoformat()
        ])

        # avoid secondary rate limit
        time.sleep(1)

    write_csv(results)

    print("\nCompleted")
    print(f"Report    : {OUTPUT_CSV}")
    print(f"Error Log : {ERROR_LOG}")

# =========================================================

if __name__ == "__main__":
    main()